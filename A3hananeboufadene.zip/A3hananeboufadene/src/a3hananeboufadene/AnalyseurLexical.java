/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3hananeboufadene;

/**
 *
 * @author admin
 */

import java.util.*;

public class AnalyseurLexical {

    public enum TokenType {
        IDENTIFIANT, NOMBRE, OPERATEUR_QUESTION, OPERATEUR_DEUX_POINTS,
        OPERATEUR_COMP, PARENTHESE_OUV, PARENTHESE_FERM, POINT_VIRGULE,
        FIN, INVALIDE
    }

    public static class Token {
        TokenType type;
        String valeur;

        public Token(TokenType type, String valeur) {
            this.type = type;
            this.valeur = valeur;
        }

        @Override
        public String toString() {
            return "<" + type + ", \"" + valeur + "\">";
        }
    }

    private static final int[][] MATRICE = {
            {1, 2, 3, 4, 5, 6, 7, 0, 8, 9},
            {1, 1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, 2, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, 3, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1},
            {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1}
    };

    private final String texte;
    private int index;
    private final List<Token> resultat;

    public AnalyseurLexical(String texte) {
        this.texte = texte;
        this.index = 0;
        this.resultat = new ArrayList<>();
    }

    private int getCategorie(char c) {
        if (Character.isLetter(c) || c == '_') return 0;
        if (Character.isDigit(c)) return 1;
        if ("<>!= ".indexOf(c) >= 0 && c != ' ') return 2;
        if (c == '?') return 3;
        if (c == ':') return 4;
        if (c == '(') return 5;
        if (c == ')') return 6;
        if (Character.isWhitespace(c)) return 7;
        if (c == ';') return 9;
        return 8;
    }

    public List<Token> analyser() {
        while (index < texte.length()) {
            int etat = 0;
            StringBuilder lexeme = new StringBuilder();
            int depart = index;

            while (index < texte.length()) {
                char c = texte.charAt(index);
                int categorie = getCategorie(c);
                int suivant = MATRICE[etat][categorie];

                if (suivant == -1) break;
                if (suivant != 0) lexeme.append(c);
                etat = suivant;
                index++;
                if (etat == 4 || etat == 5 || etat == 6 || etat == 7 || etat == 9) break;
            }

            if (lexeme.length() > 0) {
                Token t = creerToken(etat, lexeme.toString());
                if (t != null) resultat.add(t);
            } else if (etat == 0 && depart == index) {
                index++;
            }
        }

        resultat.add(new Token(TokenType.FIN, "#"));
        return resultat;
    }

    private Token creerToken(int etat, String lexeme) {
        switch (etat) {
            case 1: return new Token(TokenType.IDENTIFIANT, lexeme);
            case 2: return new Token(TokenType.NOMBRE, lexeme);
            case 3: return new Token(TokenType.OPERATEUR_COMP, lexeme);
            case 4: return new Token(TokenType.OPERATEUR_QUESTION, lexeme);
            case 5: return new Token(TokenType.OPERATEUR_DEUX_POINTS, lexeme);
            case 6: return new Token(TokenType.PARENTHESE_OUV, lexeme);
            case 7: return new Token(TokenType.PARENTHESE_FERM, lexeme);
            case 9: return new Token(TokenType.POINT_VIRGULE, lexeme);
            case 8: return new Token(TokenType.INVALIDE, lexeme);
        }
        return null;
    }

    public void afficherTokens() {
        System.out.println("=== Résultat de l'analyse lexicale ===");
        resultat.forEach(System.out::println);
    }
}
