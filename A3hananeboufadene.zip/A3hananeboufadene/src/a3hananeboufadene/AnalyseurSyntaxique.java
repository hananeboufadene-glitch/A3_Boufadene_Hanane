/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3hananeboufadene;

/**
 *
 * @author admin
 */

public class AnalyseurSyntaxique {

    public static int lireOperande(String expr, int pos, StringBuilder erreur) {
        int n = expr.length();
        if (pos >= n) {
            erreur.append("Operande attendu mais trouvé fin de l'expression.");
            return -1;
        }

        char c = expr.charAt(pos);

        if (Character.isLetterOrDigit(c)) {
            while (pos < n && (Character.isLetterOrDigit(expr.charAt(pos)) || expr.charAt(pos) == '_')) pos++;
            return pos;
        }

        if (c == '(') {
            pos++;
            while (pos < n && expr.charAt(pos) != ')') pos++;
            if (pos < n && expr.charAt(pos) == ')') return pos + 1;
            else {
                erreur.append("Parenthèse '(' sans ')' correspondante.");
                return -1;
            }
        }

        erreur.append("Operande invalide à la position ").append(pos).append(".");
        return -1;
    }

    public static boolean analyserExpression(String expr, StringBuilder erreur) {
        expr = expr.replace(" ", "");
        int i = 0, n = expr.length();
        boolean correcte = true;

        int next = lireOperande(expr, i, erreur);
        if (next == -1) correcte = false;
        else i = next;

        boolean comparaisonTrouvee = false;
        if (correcte && i < n) {
            if (expr.startsWith("==", i) || expr.startsWith("!=", i)
                    || expr.startsWith("<=", i) || expr.startsWith(">=", i)) {
                comparaisonTrouvee = true;
                i += 2;
            } else if (expr.charAt(i) == '<' || expr.charAt(i) == '>') {
                comparaisonTrouvee = true;
                i++;
            }
        }

        if (correcte && comparaisonTrouvee) {
            int old = i;
            next = lireOperande(expr, i, erreur);
            if (next == -1) {
                correcte = false;
                if (erreur.length() == 0) erreur.append("Operande droite invalide à la position ").append(old).append(".");
            } else i = next;
        }

        if (correcte) {
            if (i < n && expr.charAt(i) == '?') i++;
            else {
                correcte = false;
                erreur.append("Symbole '?' attendu à la position ").append(i).append(".");
            }
        }

        if (correcte) {
            int old = i;
            next = lireOperande(expr, i, erreur);
            if (next == -1) {
                correcte = false;
                if (erreur.length() == 0) erreur.append("Expression après '?' invalide à la position ").append(old).append(".");
            } else i = next;
        }

        if (correcte) {
            if (i < n && expr.charAt(i) == ':') i++;
            else {
                correcte = false;
                erreur.append("Symbole ':' attendu à la position ").append(i).append(".");
            }
        }

        if (correcte) {
            int old = i;
            next = lireOperande(expr, i, erreur);
            if (next == -1) {
                correcte = false;
                if (erreur.length() == 0) erreur.append("Expression après ':' invalide à la position ").append(old).append(".");
            } else i = next;
        }

        if (correcte) {
            if (i < n && expr.charAt(i) == ';') i++;
            else {
                correcte = false;
                erreur.append("Point-virgule ';' attendu à la fin de l'expression à la position ").append(i).append(".");
            }
        }

        if (correcte && i != n) {
            correcte = false;
            erreur.append("Caractères inattendus après le point-virgule à partir de la position ").append(i).append(".");
        }

        return correcte;
    }
}
