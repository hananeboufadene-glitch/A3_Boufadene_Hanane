/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package a3hananeboufadene;

/**
 *
 * @author admin
 */

import a3hananeboufadene.AnalyseurSyntaxique;
import a3hananeboufadene.AnalyseurLexical;
import java.util.Scanner;

public class MainAnalyseur {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String rep = "o";

        while (rep.equals("o") || rep.equals("oui")) {
            System.out.print("ATTENTION!! l'expression doit etre de cette maniere x?y:z; \n");
            System.out.print("Entrer une expression : ");
            String expr = sc.nextLine();

            System.out.println("\n--- Analyse Lexicale ---");
            AnalyseurLexical lexical = new AnalyseurLexical(expr);
            lexical.analyser();
            lexical.afficherTokens();

            System.out.println("\n--- Analyse Syntaxique ---");
            StringBuilder erreur = new StringBuilder();
            boolean correcte = AnalyseurSyntaxique.analyserExpression(expr, erreur);
            if (correcte) System.out.println("Expression correcte !");
            else System.out.println("Expression INCORRECTE !\nErreur : " + erreur);

            System.out.print("\nVoulez-vous analyser une autre expression ? (o/n) : ");
            rep = sc.nextLine().trim().toLowerCase();
            System.out.println();
        }

        System.out.println("Fin du programme.");
        sc.close();
    }
}
